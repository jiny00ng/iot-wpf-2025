﻿namespace WpfBookRentalShop01.ViewModels
{
    public class ObserableObject
    {
    }
}