﻿namespace WpfBookRentalShop01.Models
{
    public interface IObservableObject
    {
    }
}